/*
  # Initial Schema Setup

  1. Tables
    - users
      - id (uuid, primary key)
      - name (text)
      - mobile (text, unique)
      - created_at (timestamp)
    
    - tournaments
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - entry_fee (integer)
      - prize_pool (integer)
      - start_date (timestamp)
      - end_date (timestamp)
      - player_count (integer)
      - max_players (integer)
      - status (text)
      - created_at (timestamp)
    
    - questions
      - id (uuid, primary key)
      - text (text)
      - options (jsonb)
      - correct_answer (integer)
      - category (text)
      - difficulty (text)
      - created_at (timestamp)
    
    - quiz_attempts
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - tournament_id (uuid, references tournaments)
      - score (numeric)
      - total_questions (integer)
      - correct_answers (integer)
      - answers (jsonb)
      - start_time (timestamp)
      - end_time (timestamp)
      - created_at (timestamp)
    
    - kyc_details
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - full_name (text)
      - date_of_birth (date)
      - pan_card (text)
      - account_number (text)
      - ifsc_code (text)
      - bank_name (text)
      - verified (boolean)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  mobile text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create tournaments table
CREATE TABLE IF NOT EXISTS tournaments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  entry_fee integer NOT NULL DEFAULT 0,
  prize_pool integer NOT NULL DEFAULT 0,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  player_count integer NOT NULL DEFAULT 0,
  max_players integer NOT NULL DEFAULT 100,
  status text NOT NULL CHECK (status IN ('upcoming', 'active', 'completed')),
  created_at timestamptz DEFAULT now()
);

-- Create questions table
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  options jsonb NOT NULL,
  correct_answer integer NOT NULL,
  category text NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  created_at timestamptz DEFAULT now()
);

-- Create quiz_attempts table
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users ON DELETE CASCADE,
  tournament_id uuid REFERENCES tournaments ON DELETE CASCADE,
  score numeric NOT NULL,
  total_questions integer NOT NULL,
  correct_answers integer NOT NULL,
  answers jsonb NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create kyc_details table
CREATE TABLE IF NOT EXISTS kyc_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users ON DELETE CASCADE,
  full_name text NOT NULL,
  date_of_birth date NOT NULL,
  pan_card text NOT NULL,
  account_number text NOT NULL,
  ifsc_code text NOT NULL,
  bank_name text NOT NULL,
  verified boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE kyc_details ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Anyone can read tournaments"
  ON tournaments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can modify tournaments"
  ON tournaments
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND mobile = '9999999999' -- Admin mobile number
    )
  );

CREATE POLICY "Anyone can read questions"
  ON questions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can modify questions"
  ON questions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND mobile = '9999999999' -- Admin mobile number
    )
  );

CREATE POLICY "Users can read own quiz attempts"
  ON quiz_attempts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create quiz attempts"
  ON quiz_attempts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own KYC details"
  ON kyc_details
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own KYC details"
  ON kyc_details
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);