import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Question, Tournament, QuizAttempt } from '../types';
import { getRandomQuestions, getTournamentById, saveQuizAttempt } from '../services/tournamentService';
import { useAuth } from './AuthContext';

interface QuizContextType {
  tournament: Tournament | null;
  questions: Question[];
  currentQuestionIndex: number;
  selectedOption: number | null;
  isQuizStarted: boolean;
  isQuizFinished: boolean;
  timeRemaining: number;
  answers: { questionId: string; selectedOption: number; isCorrect: boolean; timeSpent: number }[];
  score: number;
  setTournament: (tournament: Tournament | null) => void;
  startQuiz: () => void;
  finishQuiz: () => void;
  selectOption: (optionIndex: number) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  userLeavingQuiz: boolean;
  setUserLeavingQuiz: (isLeaving: boolean) => void;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const QuizProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isQuizStarted, setIsQuizStarted] = useState(false);
  const [isQuizFinished, setIsQuizFinished] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(180); // 3 minutes in seconds
  const [answers, setAnswers] = useState<{ questionId: string; selectedOption: number; isCorrect: boolean; timeSpent: number }[]>([]);
  const [startTime, setStartTime] = useState<number>(0);
  const [questionStartTime, setQuestionStartTime] = useState<number>(0);
  const [userLeavingQuiz, setUserLeavingQuiz] = useState(false);

  // Calculate score
  const score = answers.reduce((total, answer) => {
    return total + (answer.isCorrect ? 1 : 0);
  }, 0);

  // Load random questions when tournament is set
  useEffect(() => {
    if (tournament) {
      const randomQuestions = getRandomQuestions(30);
      setQuestions(randomQuestions);
    }
  }, [tournament]);

  // Start quiz timer
  useEffect(() => {
    let timerId: number | undefined;

    if (isQuizStarted && !isQuizFinished) {
      timerId = window.setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timerId);
            finishQuiz();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isQuizStarted, isQuizFinished]);

  // Format time remaining for display
  const formatTimeRemaining = () => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const startQuiz = () => {
    setIsQuizStarted(true);
    setIsQuizFinished(false);
    setTimeRemaining(180); // Reset to 3 minutes
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setAnswers([]);
    setStartTime(Date.now());
    setQuestionStartTime(Date.now());
  };

  const finishQuiz = () => {
    setIsQuizFinished(true);
    setIsQuizStarted(false);

    if (user && tournament) {
      const endTime = Date.now();
      
      // Save quiz attempt
      const quizAttempt: QuizAttempt = {
        id: `attempt${Date.now()}`,
        userId: user.id,
        tournamentId: tournament.id,
        startTime: new Date(startTime).toISOString(),
        endTime: new Date(endTime).toISOString(),
        score: (score / questions.length) * 100,
        totalQuestions: questions.length,
        correctAnswers: score,
        answers
      };
      
      saveQuizAttempt(quizAttempt);
    }
  };

  const selectOption = (optionIndex: number) => {
    if (isQuizFinished) return;
    
    setSelectedOption(optionIndex);
    
    const currentQuestion = questions[currentQuestionIndex];
    const timeSpent = Date.now() - questionStartTime;
    const isCorrect = optionIndex === currentQuestion.correctAnswer;
    
    const answer = {
      questionId: currentQuestion.id,
      selectedOption: optionIndex,
      isCorrect,
      timeSpent
    };
    
    // Check if we already answered this question
    const existingAnswerIndex = answers.findIndex(a => a.questionId === currentQuestion.id);
    
    if (existingAnswerIndex !== -1) {
      // Update existing answer
      const updatedAnswers = [...answers];
      updatedAnswers[existingAnswerIndex] = answer;
      setAnswers(updatedAnswers);
    } else {
      // Add new answer
      setAnswers([...answers, answer]);
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setQuestionStartTime(Date.now());
    } else {
      finishQuiz();
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      
      // Set selected option to previously selected option (if any)
      const previousQuestion = questions[currentQuestionIndex - 1];
      const previousAnswer = answers.find(a => a.questionId === previousQuestion.id);
      setSelectedOption(previousAnswer ? previousAnswer.selectedOption : null);
      
      setQuestionStartTime(Date.now());
    }
  };

  return (
    <QuizContext.Provider
      value={{
        tournament,
        questions,
        currentQuestionIndex,
        selectedOption,
        isQuizStarted,
        isQuizFinished,
        timeRemaining,
        answers,
        score,
        setTournament,
        startQuiz,
        finishQuiz,
        selectOption,
        nextQuestion,
        prevQuestion,
        userLeavingQuiz,
        setUserLeavingQuiz
      }}
    >
      {children}
    </QuizContext.Provider>
  );
};

export const useQuiz = (): QuizContextType => {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
};