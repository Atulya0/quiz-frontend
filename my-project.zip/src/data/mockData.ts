import { Tournament, Question, User, QuizAttempt } from '../types';

// Mock admin user
export const adminUser: User = {
  id: 'admin1',
  name: 'Admin User',
  mobile: '9999999999',
  isAdmin: true
};

// Mock test user
export const testUser: User = {
  id: 'test1',
  name: 'Test User',
  mobile: '8888888888'
};

// Mock tournaments
export const tournaments: Tournament[] = [
  {
    id: 'tournament1',
    title: 'General Knowledge Bonanza',
    description: 'Test your general knowledge in this fast-paced quiz tournament.',
    entryFee: 50,
    prizePool: 5000,
    startDate: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
    endDate: new Date(Date.now() + 86400000 * 7).toISOString(), // Next week
    playerCount: 45,
    maxPlayers: 100,
    status: 'upcoming'
  },
  {
    id: 'tournament2',
    title: 'Science Quiz Master',
    description: 'Challenge yourself with scientific facts and discoveries.',
    entryFee: 100,
    prizePool: 10000,
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 86400000 * 3).toISOString(), // 3 days from now
    playerCount: 72,
    maxPlayers: 100,
    status: 'active'
  },
  {
    id: 'tournament3',
    title: 'History & Mythology Marathon',
    description: 'Explore the depths of history and mythology in this challenging quiz.',
    entryFee: 75,
    prizePool: 7500,
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 86400000 * 5).toISOString(), // 5 days from now
    playerCount: 63,
    maxPlayers: 100,
    status: 'active'
  },
  {
    id: 'tournament4',
    title: 'Sports Championship Quiz',
    description: 'Put your sports knowledge to the test and win big!',
    entryFee: 150,
    prizePool: 15000,
    startDate: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
    endDate: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
    playerCount: 92,
    maxPlayers: 100,
    status: 'active'
  },
  {
    id: 'tournament5',
    title: 'Tech Genius Quiz',
    description: 'Show off your tech knowledge and compete against the best!',
    entryFee: 200,
    prizePool: 20000,
    startDate: new Date(Date.now() - 86400000 * 5).toISOString(), // 5 days ago
    endDate: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    playerCount: 100,
    maxPlayers: 100,
    status: 'completed'
  }
];

// Generate 50 mock questions across different categories
export const generateMockQuestions = (): Question[] => {
  const categories = ['General Knowledge', 'Science', 'History', 'Sports', 'Technology'];
  const difficulties = ['easy', 'medium', 'hard'] as const;
  const questions: Question[] = [];

  for (let i = 0; i < 50; i++) {
    const categoryIndex = i % categories.length;
    const difficultyIndex = Math.floor(i / 20);
    
    questions.push({
      id: `question${i + 1}`,
      text: `Sample question ${i + 1} about ${categories[categoryIndex]}?`,
      options: [
        `Option A for question ${i + 1}`,
        `Option B for question ${i + 1}`,
        `Option C for question ${i + 1}`,
        `Option D for question ${i + 1}`
      ],
      correctAnswer: Math.floor(Math.random() * 4),
      category: categories[categoryIndex],
      difficulty: difficulties[difficultyIndex < difficulties.length ? difficultyIndex : 0]
    });
  }

  return questions;
};

export const questions = generateMockQuestions();

// Mock quiz attempts
export const quizAttempts: QuizAttempt[] = [
  {
    id: 'attempt1',
    userId: 'user1',
    tournamentId: 'tournament5',
    startTime: new Date(Date.now() - 86400000 * 2).toISOString(),
    endTime: new Date(Date.now() - 86400000 * 2 + 180000).toISOString(), // 3 minutes later
    score: 75,
    totalQuestions: 30,
    correctAnswers: 22,
    answers: Array(30).fill(0).map((_, i) => ({
      questionId: `question${i + 1}`,
      selectedOption: Math.floor(Math.random() * 4),
      isCorrect: Math.random() > 0.3,
      timeSpent: Math.floor(Math.random() * 10000) + 2000
    }))
  }
];

// Mock users
export const users: User[] = [
  adminUser,
  testUser,
  {
    id: 'user1',
    name: 'John Doe',
    mobile: '9876543210'
  },
  {
    id: 'user2',
    name: 'Jane Smith',
    mobile: '8765432109'
  },
  {
    id: 'user3',
    name: 'Robert Johnson',
    mobile: '7654321098'
  }
];

// Local storage keys
export const STORAGE_KEYS = {
  USER: 'quiz_tournament_user',
  TOURNAMENTS: 'quiz_tournament_tournaments',
  QUESTIONS: 'quiz_tournament_questions',
  ATTEMPTS: 'quiz_tournament_attempts',
  USERS: 'quiz_tournament_users'
};

// Initialize local storage with mock data
export const initializeLocalStorage = () => {
  if (!localStorage.getItem(STORAGE_KEYS.TOURNAMENTS)) {
    localStorage.setItem(STORAGE_KEYS.TOURNAMENTS, JSON.stringify(tournaments));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.QUESTIONS)) {
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.ATTEMPTS)) {
    localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(quizAttempts));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }
};