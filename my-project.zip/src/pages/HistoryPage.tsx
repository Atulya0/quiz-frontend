import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Header from '../components/layout/Header';
import Card, { CardBody } from '../components/common/Card';
import Button from '../components/common/Button';
import { QuizAttempt } from '../types';
import { getQuizAttemptsByUserId, getAllTournaments } from '../services/tournamentService';

const HistoryPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  
  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    
    // Load user quiz attempts
    const loadAttempts = () => {
      const userAttempts = getQuizAttemptsByUserId(user.id);
      setAttempts(userAttempts);
    };
    
    loadAttempts();
  }, [user, navigate]);
  
  // Get tournament name
  const getTournamentName = (tournamentId: string) => {
    const tournaments = getAllTournaments();
    const tournament = tournaments.find(t => t.id === tournamentId);
    return tournament ? tournament.title : 'Unknown Tournament';
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">My Quiz History</h1>
          
          <Button
            variant="outline"
            onClick={() => navigate('/tournaments')}
          >
            Back to Tournaments
          </Button>
        </div>
        
        {attempts.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No quiz attempts yet</h3>
              <p className="text-gray-500 mb-4">
                You haven't taken any quizzes yet. Start by joining a tournament and taking a quiz.
              </p>
              <Button
                onClick={() => navigate('/tournaments')}
                fullWidth
              >
                Browse Tournaments
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {attempts.map((attempt) => (
              <Card key={attempt.id}>
                <CardBody>
                  <div className="flex flex-col md:flex-row justify-between">
                    <div>
                      <h2 className="text-xl font-bold mb-1">{getTournamentName(attempt.tournamentId)}</h2>
                      <p className="text-gray-500 mb-4">Attempted on {formatDate(attempt.startTime)}</p>
                      
                      <div className="flex flex-wrap gap-4 mb-4">
                        <div className="bg-blue-50 p-3 rounded-md">
                          <p className="text-sm text-gray-600">Score</p>
                          <p className="text-xl font-bold text-blue-600">{attempt.score.toFixed(2)}%</p>
                        </div>
                        
                        <div className="bg-green-50 p-3 rounded-md">
                          <p className="text-sm text-gray-600">Correct Answers</p>
                          <p className="text-xl font-bold text-green-600">{attempt.correctAnswers} / {attempt.totalQuestions}</p>
                        </div>
                        
                        <div className="bg-purple-50 p-3 rounded-md">
                          <p className="text-sm text-gray-600">Time Used</p>
                          <p className="text-xl font-bold text-purple-600">
                            {Math.round((new Date(attempt.endTime).getTime() - new Date(attempt.startTime).getTime()) / 1000 / 60)} min
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 md:mt-0">
                      <div className="relative w-24 h-24">
                        <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                          <circle cx="50" cy="50" r="45" fill="none" stroke="#E5E7EB" strokeWidth="8" />
                          <circle 
                            cx="50" 
                            cy="50" 
                            r="45" 
                            fill="none" 
                            stroke={attempt.score >= 80 ? '#10B981' : attempt.score >= 60 ? '#3B82F6' : attempt.score >= 40 ? '#F59E0B' : '#EF4444'} 
                            strokeWidth="8"
                            strokeDasharray="282.7"
                            strokeDashoffset={282.7 - ((attempt.score / 100) * 282.7)}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-2xl font-bold">{Math.round(attempt.score)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPage;