import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuiz } from '../context/QuizContext';
import QuizResults from '../components/results/QuizResults';

const ResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const { tournament, isQuizFinished } = useQuiz();
  
  // Redirect if quiz is not finished or no tournament is selected
  useEffect(() => {
    if (!tournament || !isQuizFinished) {
      navigate('/tournaments');
    }
  }, [tournament, isQuizFinished, navigate]);
  
  if (!tournament || !isQuizFinished) {
    return null;
  }
  
  return <QuizResults />;
};

export default ResultsPage;