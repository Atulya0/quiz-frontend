import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Header from '../components/layout/Header';
import QuestionManager from '../components/admin/QuestionManager';
import UserReports from '../components/admin/UserReports';

const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'questions' | 'users'>('questions');
  
  // Redirect if user is not admin
  if (!user?.isAdmin) {
    return <Navigate to="/tournaments" />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="flex border-b">
            <button
              className={`flex-1 py-4 px-6 text-center font-medium focus:outline-none transition-colors ${
                activeTab === 'questions'
                  ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveTab('questions')}
            >
              Manage Questions
            </button>
            <button
              className={`flex-1 py-4 px-6 text-center font-medium focus:outline-none transition-colors ${
                activeTab === 'users'
                  ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveTab('users')}
            >
              User Reports
            </button>
          </div>
          
          <div className="p-0">
            {activeTab === 'questions' ? (
              <QuestionManager />
            ) : (
              <UserReports />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;