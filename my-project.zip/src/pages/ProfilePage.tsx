import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Header from '../components/layout/Header';
import Button from '../components/common/Button';
import Card, { CardBody } from '../components/common/Card';
import { getQuizAttemptsByUserId } from '../services/tournamentService';

const ProfilePage: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [totalAttempts, setTotalAttempts] = useState(0);
  const [averageScore, setAverageScore] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  
  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    
    // Load user stats
    const loadUserStats = () => {
      const userAttempts = getQuizAttemptsByUserId(user.id);
      setTotalAttempts(userAttempts.length);
      
      if (userAttempts.length > 0) {
        const totalScore = userAttempts.reduce((sum, attempt) => sum + attempt.score, 0);
        setAverageScore(totalScore / userAttempts.length);
        
        const maxScore = Math.max(...userAttempts.map(attempt => attempt.score));
        setBestScore(maxScore);
      }
    };
    
    loadUserStats();
  }, [user, navigate]);
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  if (!user) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">My Profile</h1>
          
          <Button
            variant="outline"
            onClick={() => navigate('/tournaments')}
          >
            Back to Tournaments
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-1">
            <Card className="sticky top-8">
              <CardBody>
                <div className="flex flex-col items-center">
                  <div className="w-24 h-24 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center mb-4">
                    <span className="text-3xl font-bold text-white">{user.name.charAt(0).toUpperCase()}</span>
                  </div>
                  
                  <h2 className="text-xl font-bold mb-1">{user.name}</h2>
                  <p className="text-gray-500 mb-4">{user.mobile}</p>
                  
                  <div className="w-full mt-4 space-y-3">
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => navigate('/history')}
                    >
                      Quiz History
                    </Button>
                    
                    <Button
                      variant="danger"
                      fullWidth
                      onClick={handleLogout}
                    >
                      Logout
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          </div>
          
          <div className="md:col-span-3">
            <Card className="mb-6">
              <CardBody>
                <h3 className="text-lg font-bold mb-4">Quiz Statistics</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Total Quizzes</p>
                    <p className="text-3xl font-bold text-blue-600">{totalAttempts}</p>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Average Score</p>
                    <p className="text-3xl font-bold text-green-600">{averageScore.toFixed(2)}%</p>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Best Score</p>
                    <p className="text-3xl font-bold text-purple-600">{bestScore.toFixed(2)}%</p>
                  </div>
                </div>
              </CardBody>
            </Card>
            
            <Card>
              <CardBody>
                <h3 className="text-lg font-bold mb-4">Account Information</h3>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">Name</p>
                    <p className="font-medium">{user.name}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Mobile Number</p>
                    <p className="font-medium">{user.mobile}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Account Type</p>
                    <p className="font-medium">
                      {user.isAdmin ? (
                        <span className="text-purple-600">Administrator</span>
                      ) : user.id === 'test1' ? (
                        <span className="text-blue-600">Test User</span>
                      ) : (
                        <span>Regular User</span>
                      )}
                    </p>
                  </div>
                  
                  {user.isAdmin && (
                    <div className="pt-4">
                      <Button
                        onClick={() => navigate('/admin')}
                      >
                        Go to Admin Dashboard
                      </Button>
                    </div>
                  )}
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;