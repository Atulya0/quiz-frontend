import React, { useEffect, useState } from 'react';
import Header from '../components/layout/Header';
import TournamentCard from '../components/home/TournamentCard';
import { Tournament } from '../types';
import { supabase } from '../lib/supabase';

const TournamentsPage: React.FC = () => {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [activeFilter, setActiveFilter] = useState<'active' | 'upcoming'>('active');
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const loadTournaments = async () => {
      try {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('tournaments')
          .select('*')
          .in('status', ['active', 'upcoming'])
          .order('start_date', { ascending: true });
        
        if (error) throw error;
        
        setTournaments(data || []);
      } catch (error) {
        console.error('Error loading tournaments:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadTournaments();
  }, []);
  
  // Filter tournaments based on active filter
  const filteredTournaments = tournaments.filter(tournament => tournament.status === activeFilter);
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading tournaments...</p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 space-y-4 md:space-y-0">
          <h1 className="text-3xl font-bold text-gray-800">Tournaments</h1>
          
          <div className="flex space-x-2 w-full md:w-auto">
            <button
              onClick={() => setActiveFilter('active')}
              className={`flex-1 md:flex-none px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === 'active'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              Active
            </button>
            <button
              onClick={() => setActiveFilter('upcoming')}
              className={`flex-1 md:flex-none px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === 'upcoming'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              Upcoming
            </button>
          </div>
        </div>
        
        {filteredTournaments.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tournaments found</h3>
              <p className="text-gray-500">
                There are no {activeFilter} tournaments available at the moment. Please check back later.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTournaments.map(tournament => (
              <TournamentCard
                key={tournament.id}
                tournament={tournament}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TournamentsPage;