import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import QuizGame from '../components/quiz/QuizGame';
import { useQuiz } from '../context/QuizContext';

const QuizPage: React.FC = () => {
  const navigate = useNavigate();
  const { tournament } = useQuiz();
  
  // Redirect if no tournament is selected
  useEffect(() => {
    if (!tournament) {
      navigate('/tournaments');
    }
  }, [tournament, navigate]);
  
  if (!tournament) {
    return null;
  }
  
  return <QuizGame />;
};

export default QuizPage;