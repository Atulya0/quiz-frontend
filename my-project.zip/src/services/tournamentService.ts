import { Tournament, Question, QuizAttempt, User } from '../types';
import { STORAGE_KEYS } from '../data/mockData';

// Get all tournaments
export const getAllTournaments = (): Tournament[] => {
  const tournamentsJson = localStorage.getItem(STORAGE_KEYS.TOURNAMENTS);
  return tournamentsJson ? JSON.parse(tournamentsJson) : [];
};

// Get tournament by ID
export const getTournamentById = (id: string): Tournament | null => {
  const tournaments = getAllTournaments();
  return tournaments.find(tournament => tournament.id === id) || null;
};

// Get random questions for a quiz
export const getRandomQuestions = (count: number = 30): Question[] => {
  const questionsJson = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
  const allQuestions: Question[] = questionsJson ? JSON.parse(questionsJson) : [];
  
  // Shuffle questions and take the first 'count'
  return [...allQuestions]
    .sort(() => Math.random() - 0.5)
    .slice(0, count);
};

// Save quiz attempt
export const saveQuizAttempt = (attempt: QuizAttempt): void => {
  const attemptsJson = localStorage.getItem(STORAGE_KEYS.ATTEMPTS);
  const attempts: QuizAttempt[] = attemptsJson ? JSON.parse(attemptsJson) : [];
  
  attempts.push(attempt);
  localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(attempts));
};

// Get all quiz attempts
export const getAllQuizAttempts = (): QuizAttempt[] => {
  const attemptsJson = localStorage.getItem(STORAGE_KEYS.ATTEMPTS);
  return attemptsJson ? JSON.parse(attemptsJson) : [];
};

// Get quiz attempts by user ID
export const getQuizAttemptsByUserId = (userId: string): QuizAttempt[] => {
  const attempts = getAllQuizAttempts();
  return attempts.filter(attempt => attempt.userId === userId);
};

// Get all users
export const getAllUsers = (): User[] => {
  const usersJson = localStorage.getItem(STORAGE_KEYS.USERS);
  return usersJson ? JSON.parse(usersJson) : [];
};

// Admin: Add a new question
export const addQuestion = (question: Question): void => {
  const questionsJson = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
  const questions: Question[] = questionsJson ? JSON.parse(questionsJson) : [];
  
  questions.push(question);
  localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
};

// Admin: Update a question
export const updateQuestion = (question: Question): void => {
  const questionsJson = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
  const questions: Question[] = questionsJson ? JSON.parse(questionsJson) : [];
  
  const index = questions.findIndex(q => q.id === question.id);
  if (index !== -1) {
    questions[index] = question;
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
  }
};

// Admin: Delete a question
export const deleteQuestion = (id: string): void => {
  const questionsJson = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
  const questions: Question[] = questionsJson ? JSON.parse(questionsJson) : [];
  
  const filteredQuestions = questions.filter(q => q.id !== id);
  localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(filteredQuestions));
};

// Admin: Get all questions
export const getAllQuestions = (): Question[] => {
  const questionsJson = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
  return questionsJson ? JSON.parse(questionsJson) : [];
};