import { User } from '../types';
import { STORAGE_KEYS, adminUser, testUser } from '../data/mockData';

export const loginUser = (mobile: string, name: string): User | null => {
  // Get users from local storage
  const usersJson = localStorage.getItem(STORAGE_KEYS.USERS);
  const users: User[] = usersJson ? JSON.parse(usersJson) : [];
  
  // Check if user is admin
  if (mobile === adminUser.mobile) {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(adminUser));
    return adminUser;
  }
  
  // Check if user is test user
  if (mobile === testUser.mobile) {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(testUser));
    return testUser;
  }
  
  // Check if user exists
  let user = users.find(user => user.mobile === mobile);
  
  // If user doesn't exist, create a new one
  if (!user) {
    user = {
      id: `user${Date.now()}`,
      name,
      mobile
    };
    
    // Add user to users array
    users.push(user);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }
  
  // Store user in local storage
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  
  return user;
};

export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(STORAGE_KEYS.USER);
  return userJson ? JSON.parse(userJson) : null;
};

export const logoutUser = (): void => {
  localStorage.removeItem(STORAGE_KEYS.USER);
};

export const isAdmin = (): boolean => {
  const user = getCurrentUser();
  return user?.isAdmin === true;
};