import React, { useState, useEffect } from 'react';

const HyperspeedBackground: React.FC = () => {
  const [stars, setStars] = useState<{ x: number; y: number; size: number; speed: number; opacity: number }[]>([]);

  useEffect(() => {
    const generateStars = () => {
      const newStars = [];
      for (let i = 0; i < 200; i++) {
        newStars.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          size: Math.random() * 2 + 1,
          speed: Math.random() * 5 + 2,
          opacity: Math.random() * 0.8 + 0.2
        });
      }
      setStars(newStars);
    };

    generateStars();

    const handleResize = () => {
      generateStars();
    };

    window.addEventListener('resize', handleResize);
    
    const animateStars = () => {
      setStars(prevStars => 
        prevStars.map(star => {
          let x = star.x + star.speed;
          let opacity = star.opacity;
          
          // Reset star when it goes off screen
          if (x > window.innerWidth) {
            x = 0;
            opacity = Math.random() * 0.8 + 0.2;
          }
          
          return {
            ...star,
            x,
            opacity
          };
        })
      );
    };

    const animationId = setInterval(animateStars, 20);

    return () => {
      window.removeEventListener('resize', handleResize);
      clearInterval(animationId);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 bg-slate-900 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-indigo-900 to-purple-900 opacity-20"></div>
      <svg className="absolute inset-0 w-full h-full">
        {stars.map((star, index) => (
          <circle
            key={index}
            cx={star.x}
            cy={star.y}
            r={star.size}
            fill="white"
            opacity={star.opacity}
            style={{
              filter: `blur(${star.size === 3 ? 1 : 0}px)`,
              transform: `scale(${1 + star.speed / 10})`,
            }}
          />
        ))}
      </svg>
    </div>
  );
};

export default HyperspeedBackground;