import React, { InputHTMLAttributes } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  fullWidth?: boolean;
}

const Input: React.FC<InputProps> = ({
  label,
  error,
  fullWidth = false,
  className = '',
  ...props
}) => {
  const widthStyle = fullWidth ? "w-full" : "";
  const inputStyles = `px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 
    focus:outline-none focus:border-blue-500 focus:ring-blue-500 block rounded-md sm:text-sm focus:ring-1 
    ${error ? 'border-red-500' : 'border-gray-300'} ${widthStyle} ${className}`;

  return (
    <div className={`mb-4 ${widthStyle}`}>
      {label && (
        <label htmlFor={props.id} className="block text-sm font-medium text-white mb-1">
          {label}
        </label>
      )}
      <input className={inputStyles} {...props} />
      {error && <p className="mt-1 text-sm text-red-400">{error}</p>}
    </div>
  );
};

export default Input;