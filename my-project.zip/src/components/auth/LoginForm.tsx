import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';
import Input from '../common/Input';
import HyperspeedBackground from '../common/HyperspeedBackground';

const LoginForm: React.FC = () => {
  const [mobile, setMobile] = useState('');
  const [name, setName] = useState('');
  const [mobileError, setMobileError] = useState('');
  const [nameError, setNameError] = useState('');
  
  const { login, isLoading, error } = useAuth();

  const validateForm = () => {
    let isValid = true;
    
    if (!mobile) {
      setMobileError('Mobile number is required');
      isValid = false;
    } else if (!/^[0-9]{10}$/.test(mobile)) {
      setMobileError('Please enter a valid 10-digit mobile number');
      isValid = false;
    } else {
      setMobileError('');
    }
    
    if (!name) {
      setNameError('Name is required');
      isValid = false;
    } else if (name.length < 3) {
      setNameError('Name must be at least 3 characters long');
      isValid = false;
    } else {
      setNameError('');
    }
    
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    try {
      await login(mobile, name);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <>
      <HyperspeedBackground />
      <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-lg shadow-xl w-full max-w-md border border-white/20">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-white/20 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M8.812 9.483a2.57 2.57 0 0 0-.786-1.287A2.57 2.57 0 0 0 6.7 7.5H3.5A1.5 1.5 0 0 0 2 9v1.909l1.279.855L4.2 11.1a2 2 0 0 1 .9.9l.3.6"></path>
                <path d="M1.998 17 2 13l6-2.958V7.5"></path>
                <path d="M15.194 9.482a2.57 2.57 0 0 1 .787-1.287A2.57 2.57 0 0 1 17.3 7.5H20.5a1.5 1.5 0 0 1 1.5 1.5v1.909l-1.279.855L19.8 11.1a2 2 0 0 0-.9.9l-.3.6"></path>
                <path d="M21.998 17 22 13l-6-2.958V7.5"></path>
                <path d="M12 22v-5"></path>
                <path d="m9 9 1.5-1.5h3L15 9"></path>
                <path d="M8 13v-2a4 4 0 0 1 8 0v2"></path>
                <rect width="16" height="7" x="4" y="13" rx="2"></rect>
              </svg>
            </div>
          </div>
          
          <h2 className="text-3xl font-bold text-center mb-2 text-white">QuizMaster</h2>
          <p className="text-center text-white/80 mb-6">Join tournaments, test your knowledge, win prizes!</p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="tel"
              id="mobile"
              label="Mobile Number"
              placeholder="Enter your 10-digit mobile number"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              fullWidth
              error={mobileError}
              maxLength={10}
              className="bg-white/5 border-white/20 text-white placeholder-white/50"
            />
            
            <Input
              type="text"
              id="name"
              label="Full Name"
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              fullWidth
              error={nameError}
              className="bg-white/5 border-white/20 text-white placeholder-white/50"
            />
            
            {error && (
              <div className="text-red-400 text-sm mt-2">{error}</div>
            )}
            
            <Button
              type="submit"
              fullWidth
              isLoading={isLoading}
              className="bg-white/20 hover:bg-white/30 text-white"
            >
              Log In / Sign Up
            </Button>
          </form>
        </div>
      </div>
    </>
  );
};

export default LoginForm;