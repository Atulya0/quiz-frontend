import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuiz } from '../../context/QuizContext';
import Button from '../common/Button';
import Modal from '../common/Modal';

const QuizGame: React.FC = () => {
  const navigate = useNavigate();
  const {
    tournament,
    questions,
    currentQuestionIndex,
    selectedOption,
    isQuizStarted,
    isQuizFinished,
    timeRemaining,
    answers,
    score,
    startQuiz,
    finishQuiz,
    selectOption,
    nextQuestion,
    prevQuestion,
    userLeavingQuiz,
    setUserLeavingQuiz
  } = useQuiz();
  
  const [isExitModalOpen, setIsExitModalOpen] = useState(false);

  // Handle quiz completion
  useEffect(() => {
    if (isQuizFinished) {
      navigate('/results');
    }
  }, [isQuizFinished, navigate]);

  // Start the quiz when component mounts
  useEffect(() => {
    if (!isQuizStarted && !isQuizFinished) {
      startQuiz();
    }
  }, [isQuizStarted, isQuizFinished, startQuiz]);

  // Prevent tab switching or leaving the page
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && isQuizStarted && !isQuizFinished) {
        setUserLeavingQuiz(true);
      }
    };

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isQuizStarted && !isQuizFinished) {
        e.preventDefault();
        e.returnValue = '';
        return '';
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isQuizStarted, isQuizFinished, setUserLeavingQuiz]);

  // Format time remaining
  const formatTimeRemaining = () => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  // Calculate progress percentage
  const progressPercentage = (answers.length / questions.length) * 100;
  
  // Get current question
  const currentQuestion = questions[currentQuestionIndex];
  
  // Check if current question has been answered
  const isCurrentQuestionAnswered = answers.some(a => a.questionId === currentQuestion?.id);

  // Handle early finish
  const handleFinishEarly = () => {
    finishQuiz();
  };

  // Handle exit quiz
  const handleExitQuiz = () => {
    finishQuiz();
    navigate('/tournaments');
  };

  if (!tournament || !currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading quiz...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-4 pb-16">
      {/* Quiz Header */}
      <div className="bg-white shadow-md rounded-lg max-w-3xl mx-auto mb-6 p-4">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-xl font-bold text-gray-800">{tournament.title}</h1>
            <p className="text-sm text-gray-600">
              Question {currentQuestionIndex + 1} of {questions.length}
            </p>
          </div>
          <div className="text-center">
            <div className={`text-lg font-bold ${timeRemaining < 30 ? 'text-red-600 animate-pulse' : 'text-blue-600'}`}>
              {formatTimeRemaining()}
            </div>
            <p className="text-xs text-gray-500">Time Remaining</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white shadow-md rounded-lg max-w-3xl mx-auto mb-6 p-6">
        <h2 className="text-xl font-medium mb-6">{currentQuestion.text}</h2>

        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => (
            <div
              key={index}
              className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 ${
                selectedOption === index 
                  ? 'border-blue-500 bg-blue-50 shadow-md' 
                  : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50/50'
              }`}
              onClick={() => selectOption(index)}
            >
              <div className="flex items-start">
                <div className={`w-6 h-6 flex items-center justify-center rounded-full mr-3 ${
                  selectedOption === index 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {String.fromCharCode(65 + index)}
                </div>
                <div className="flex-1">
                  {option}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg p-4">
        <div className="max-w-3xl mx-auto flex justify-between">
          <Button
            variant="outline"
            onClick={prevQuestion}
            disabled={currentQuestionIndex === 0}
          >
            Previous
          </Button>

          <div className="flex space-x-2">
            <Button
              variant="danger"
              onClick={() => setIsExitModalOpen(true)}
            >
              Exit Quiz
            </Button>

            {isCurrentQuestionAnswered && currentQuestionIndex === questions.length - 1 && (
              <Button
                variant="success"
                onClick={handleFinishEarly}
              >
                Finish Quiz
              </Button>
            )}

            <Button
              onClick={nextQuestion}
              disabled={!isCurrentQuestionAnswered}
            >
              {currentQuestionIndex === questions.length - 1 ? 'Finish' : 'Next'}
            </Button>
          </div>
        </div>
      </div>

      {/* Tab Warning Modal */}
      <Modal
        isOpen={userLeavingQuiz}
        onClose={() => setUserLeavingQuiz(false)}
        title="Warning!"
      >
        <div className="p-4 bg-red-50 rounded-md mb-4">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <h3 className="font-bold text-lg text-red-700">Violation Detected!</h3>
          </div>
          <p className="mt-2 text-red-600">
            You have switched tabs or left the quiz page, which is against the quiz rules.
            Further violations may lead to disqualification.
          </p>
        </div>
        <div className="flex justify-end">
          <Button onClick={() => setUserLeavingQuiz(false)}>
            I Understand
          </Button>
        </div>
      </Modal>

      {/* Exit Confirmation Modal */}
      <Modal
        isOpen={isExitModalOpen}
        onClose={() => setIsExitModalOpen(false)}
        title="Exit Quiz?"
      >
        <div className="p-4 bg-yellow-50 rounded-md mb-4">
          <p className="text-yellow-800">
            Are you sure you want to exit the quiz? Your current progress will be submitted and you cannot return to this quiz.
          </p>
        </div>
        <div className="flex justify-end space-x-3">
          <Button 
            variant="outline" 
            onClick={() => setIsExitModalOpen(false)}
          >
            Cancel
          </Button>
          <Button 
            variant="danger" 
            onClick={handleExitQuiz}
          >
            Exit Quiz
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default QuizGame;