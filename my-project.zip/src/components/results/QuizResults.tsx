import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuiz } from '../../context/QuizContext';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';
import Modal from '../common/Modal';
import Input from '../common/Input';
import { supabase } from '../../lib/supabase';

const QuizResults: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { tournament, questions, answers, score, timeRemaining } = useQuiz();
  
  const [isKYCModalOpen, setIsKYCModalOpen] = useState(false);
  const [isCongratulationsModalOpen, setIsCongratulationsModalOpen] = useState(false);
  const [kycForm, setKYCForm] = useState({
    fullName: user?.name || '',
    dateOfBirth: '',
    panCard: '',
    accountNumber: '',
    ifscCode: '',
    bankName: ''
  });
  const [kycErrors, setKYCErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!tournament || !user) {
    navigate('/tournaments');
    return null;
  }
  
  // Calculate score percentage
  const scorePercentage = (score / questions.length) * 100;
  
  // Determine result message and color
  const getResultFeedback = () => {
    if (scorePercentage >= 80) {
      return {
        message: 'Excellent! You did great!',
        color: 'text-green-600'
      };
    } else if (scorePercentage >= 60) {
      return {
        message: 'Good job! You did well!',
        color: 'text-blue-600'
      };
    } else if (scorePercentage >= 40) {
      return {
        message: 'Not bad, keep practicing!',
        color: 'text-yellow-600'
      };
    } else {
      return {
        message: 'Keep learning and try again!',
        color: 'text-red-600'
      };
    }
  };
  
  const feedback = getResultFeedback();
  
  // Calculate time used
  const timeUsed = 180 - timeRemaining;
  const formattedTimeUsed = `${Math.floor(timeUsed / 60)}:${(timeUsed % 60).toString().padStart(2, '0')}`;
  
  // Handle KYC form change
  const handleKYCFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setKYCForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Validate KYC form
  const validateKYCForm = () => {
    const errors: Record<string, string> = {};
    
    if (!kycForm.fullName) {
      errors.fullName = 'Full name is required';
    }
    
    if (!kycForm.dateOfBirth) {
      errors.dateOfBirth = 'Date of birth is required';
    }
    
    if (!kycForm.panCard) {
      errors.panCard = 'PAN card number is required';
    } else if (!/[A-Z]{5}[0-9]{4}[A-Z]{1}/.test(kycForm.panCard)) {
      errors.panCard = 'Invalid PAN card format';
    }
    
    if (!kycForm.accountNumber) {
      errors.accountNumber = 'Account number is required';
    }
    
    if (!kycForm.ifscCode) {
      errors.ifscCode = 'IFSC code is required';
    } else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(kycForm.ifscCode)) {
      errors.ifscCode = 'Invalid IFSC code format';
    }
    
    if (!kycForm.bankName) {
      errors.bankName = 'Bank name is required';
    }
    
    setKYCErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Handle KYC submission
  const handleKYCSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateKYCForm() || !user) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const { error } = await supabase.from('kyc_details').insert({
        user_id: user.id,
        full_name: kycForm.fullName,
        date_of_birth: kycForm.dateOfBirth,
        pan_card: kycForm.panCard,
        account_number: kycForm.accountNumber,
        ifsc_code: kycForm.ifscCode,
        bank_name: kycForm.bankName
      });

      if (error) throw error;

      setIsKYCModalOpen(false);
      setIsCongratulationsModalOpen(true);
    } catch (error) {
      console.error('Error submitting KYC:', error);
      alert('Failed to submit KYC details. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
            <h1 className="text-2xl font-bold mb-2">Quiz Results</h1>
            <p>{tournament.title}</p>
          </div>
          
          {/* Score Card */}
          <div className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between mb-8">
              <div className="mb-4 md:mb-0 text-center md:text-left">
                <h2 className="text-4xl font-bold mb-2 text-blue-600">{score} / {questions.length}</h2>
                <p className={`text-lg font-medium ${feedback.color}`}>{feedback.message}</p>
              </div>
              
              <div className="relative w-32 h-32">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                  <circle 
                    cx="50" 
                    cy="50" 
                    r="45" 
                    fill="none" 
                    stroke="#E5E7EB" 
                    strokeWidth="8" 
                  />
                  <circle 
                    cx="50" 
                    cy="50" 
                    r="45" 
                    fill="none" 
                    stroke={scorePercentage >= 80 ? '#10B981' : scorePercentage >= 60 ? '#3B82F6' : scorePercentage >= 40 ? '#F59E0B' : '#EF4444'} 
                    strokeWidth="8"
                    strokeDasharray="282.7"
                    strokeDashoffset={282.7 - ((scorePercentage) / 100 * 282.7)}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold">{Math.round(scorePercentage)}%</span>
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-blue-50 rounded-lg p-4 text-center">
                <p className="text-sm text-blue-600 font-medium">Correct Answers</p>
                <p className="text-2xl font-bold text-blue-700">{score}</p>
              </div>
              
              <div className="bg-red-50 rounded-lg p-4 text-center">
                <p className="text-sm text-red-600 font-medium">Incorrect Answers</p>
                <p className="text-2xl font-bold text-red-700">{questions.length - score}</p>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-4 text-center">
                <p className="text-sm text-purple-600 font-medium">Time Used</p>
                <p className="text-2xl font-bold text-purple-700">{formattedTimeUsed}</p>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <Button 
                variant="primary" 
                fullWidth
                onClick={() => setIsKYCModalOpen(true)}
              >
                Claim Your Prize
              </Button>
              
              <Button 
                variant="outline" 
                fullWidth
                onClick={() => navigate('/tournaments')}
              >
                Back to Tournaments
              </Button>
            </div>
          </div>
        </div>
        
        {/* Answers Section */}
        <div className="bg-white shadow-md rounded-lg p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">Your Answers</h2>
          
          <div className="space-y-6">
            {questions.map((question, index) => {
              const answer = answers.find(a => a.questionId === question.id);
              const isCorrect = answer?.isCorrect;
              
              return (
                <div key={question.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                  <div className="flex items-start mb-2">
                    <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full mr-2 text-sm ${
                      isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {index + 1}
                    </span>
                    <h3 className="text-lg font-medium">{question.text}</h3>
                  </div>
                  
                  <div className="pl-8 space-y-1">
                    {question.options.map((option, optIndex) => (
                      <div key={optIndex} className={`p-2 rounded ${
                        optIndex === question.correctAnswer
                          ? 'bg-green-100 text-green-800'
                          : optIndex === answer?.selectedOption && !isCorrect
                            ? 'bg-red-100 text-red-800'
                            : ''
                      }`}>
                        <div className="flex items-center">
                          <span className="w-6 inline-block">{String.fromCharCode(65 + optIndex)}.</span>
                          <span>{option}</span>
                          {optIndex === question.correctAnswer && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* KYC Modal */}
      <Modal
        isOpen={isKYCModalOpen}
        onClose={() => !isSubmitting && setIsKYCModalOpen(false)}
        title="Complete KYC for Prize Claim"
        size="lg"
      >
        <form onSubmit={handleKYCSubmit} className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-md mb-4">
            <p className="text-blue-800">
              To claim your prize, we need to verify your identity and bank details. This information is required for regulatory compliance and to process your winnings.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Full Name (as per PAN Card)"
              type="text"
              name="fullName"
              value={kycForm.fullName}
              onChange={handleKYCFormChange}
              error={kycErrors.fullName}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
            
            <Input
              label="Date of Birth"
              type="date"
              name="dateOfBirth"
              value={kycForm.dateOfBirth}
              onChange={handleKYCFormChange}
              error={kycErrors.dateOfBirth}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
            
            <Input
              label="PAN Card Number"
              type="text"
              name="panCard"
              placeholder="ABCDE1234F"
              value={kycForm.panCard}
              onChange={handleKYCFormChange}
              error={kycErrors.panCard}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
            
            <Input
              label="Bank Account Number"
              type="text"
              name="accountNumber"
              placeholder="Your account number"
              value={kycForm.accountNumber}
              onChange={handleKYCFormChange}
              error={kycErrors.accountNumber}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
            
            <Input
              label="IFSC Code"
              type="text"
              name="ifscCode"
              placeholder="XXXX0XXXXXX"
              value={kycForm.ifscCode}
              onChange={handleKYCFormChange}
              error={kycErrors.ifscCode}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
            
            <Input
              label="Bank Name"
              type="text"
              name="bankName"
              placeholder="Your bank name"
              value={kycForm.bankName}
              onChange={handleKYCFormChange}
              error={kycErrors.bankName}
              fullWidth
              className="bg-white border-gray-300 text-gray-900"
            />
          </div>
          
          <div className="flex justify-end space-x-3 mt-6">
            <Button
              variant="outline"
              onClick={() => setIsKYCModalOpen(false)}
              disabled={isSubmitting}
              type="button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              isLoading={isSubmitting}
            >
              Submit KYC Details
            </Button>
          </div>
        </form>
      </Modal>
      
      {/* Congratulations Modal */}
      <Modal
        isOpen={isCongratulationsModalOpen}
        onClose={() => setIsCongratulationsModalOpen(false)}
        title="Congratulations!"
      >
        <div className="text-center py-4">
          <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-600" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
          </div>
          
          <h3 className="text-2xl font-bold text-gray-800 mb-2">KYC Submitted Successfully!</h3>
          <p className="text-gray-600 mb-6">
            Your winning amount will be credited to your bank account within 24 hours. You will receive an SMS notification once the transfer is complete.
          </p>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-6 text-left">
            <p className="text-yellow-800 font-medium">Your Prize Amount: ₹{Math.round(tournament.prizePool * 0.6)}</p>
            <p className="text-yellow-700 text-sm">As the top performer, you've won 60% of the prize pool!</p>
          </div>
          
          <Button
            onClick={() => {
              setIsCongratulationsModalOpen(false);
              navigate('/tournaments');
            }}
          >
            Return to Tournaments
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default QuizResults;