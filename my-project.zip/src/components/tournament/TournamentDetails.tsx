import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Tournament } from '../../types';
import Button from '../common/Button';
import Card, { CardBody, CardHeader, CardFooter } from '../common/Card';
import Modal from '../common/Modal';
import { testUser } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import { useQuiz } from '../../context/QuizContext';

interface TournamentDetailsProps {
  tournament: Tournament;
}

const TournamentDetails: React.FC<TournamentDetailsProps> = ({ tournament }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { setTournament } = useQuiz();
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const handleStartQuiz = () => {
    setTournament(tournament);
    navigate('/quiz');
  };
  
  const handleEnterTournament = () => {
    if (user?.id === testUser.id) {
      // Test user can skip payment
      setIsRulesModalOpen(true);
    } else {
      setIsPaymentModalOpen(true);
    }
  };
  
  const handlePayment = () => {
    setIsProcessingPayment(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessingPayment(false);
      setIsPaymentModalOpen(false);
      setIsRulesModalOpen(true);
    }, 2000);
  };
  
  const handleAcceptRules = () => {
    setIsRulesModalOpen(false);
    handleStartQuiz();
  };
  
  return (
    <>
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-xl mb-6">
        <h1 className="text-3xl font-bold mb-2">{tournament.title}</h1>
        <p className="mb-4">{tournament.description}</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div className="bg-white/20 backdrop-blur-md p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Tournament Details</h3>
            <p className="text-sm">Start: {formatDate(tournament.startDate)}</p>
            <p className="text-sm">End: {formatDate(tournament.endDate)}</p>
          </div>
          
          <div className="bg-white/20 backdrop-blur-md p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Entry & Prize</h3>
            <p className="text-sm">Entry Fee: ₹{tournament.entryFee}</p>
            <p className="text-sm">Prize Pool: ₹{tournament.prizePool}</p>
          </div>
          
          <div className="bg-white/20 backdrop-blur-md p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Participants</h3>
            <div className="w-full bg-white/30 rounded-full h-2 mb-2">
              <div 
                className="bg-green-400 h-2 rounded-full" 
                style={{ width: `${(tournament.playerCount / tournament.maxPlayers) * 100}%` }}
              ></div>
            </div>
            <p className="text-sm">{tournament.playerCount} / {tournament.maxPlayers} players</p>
          </div>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold">Tournament Rules</h2>
        </CardHeader>
        
        <CardBody>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-lg mb-2">Quiz Format</h3>
              <ul className="list-disc pl-5 text-gray-700">
                <li>30 multiple-choice questions to be answered in 3 minutes</li>
                <li>Questions are randomly selected from our database</li>
                <li>Each question has 4 possible answers with only one correct option</li>
                <li>You can navigate between questions during the quiz</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Scoring</h3>
              <ul className="list-disc pl-5 text-gray-700">
                <li>Each correct answer earns 1 point</li>
                <li>No negative marking for incorrect answers</li>
                <li>The highest score wins; in case of a tie, the faster completion time prevails</li>
                <li>Results are final and cannot be contested</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-lg mb-2">Prize Distribution</h3>
              <ul className="list-disc pl-5 text-gray-700">
                <li>1st Place: 60% of prize pool</li>
                <li>2nd Place: 30% of prize pool</li>
                <li>3rd Place: 10% of prize pool</li>
                <li>Winners will need to complete KYC verification before receiving prizes</li>
              </ul>
            </div>
          </div>
        </CardBody>
        
        <CardFooter className="flex justify-center">
          {tournament.status === 'active' && (
            <Button onClick={handleEnterTournament} size="lg">
              Enter Tournament (₹{tournament.entryFee})
            </Button>
          )}
          
          {tournament.status === 'upcoming' && (
            <Button variant="secondary" size="lg" disabled>
              Tournament starts on {formatDate(tournament.startDate)}
            </Button>
          )}
          
          {tournament.status === 'completed' && (
            <Button variant="outline" size="lg" onClick={() => navigate('/leaderboard')}>
              View Results
            </Button>
          )}
        </CardFooter>
      </Card>
      
      {/* Payment Modal */}
      <Modal
        isOpen={isPaymentModalOpen}
        onClose={() => !isProcessingPayment && setIsPaymentModalOpen(false)}
        title="Tournament Payment"
      >
        <div className="space-y-6">
          <div className="p-4 bg-blue-50 rounded-md">
            <h3 className="font-medium text-lg mb-2">Payment Summary</h3>
            <div className="flex justify-between mb-2">
              <span>Tournament Entry Fee:</span>
              <span className="font-medium">₹{tournament.entryFee}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>GST (18%):</span>
              <span className="font-medium">₹{Math.round(tournament.entryFee * 0.18)}</span>
            </div>
            <div className="border-t pt-2 mt-2 flex justify-between">
              <span className="font-bold">Total Amount:</span>
              <span className="font-bold">₹{tournament.entryFee + Math.round(tournament.entryFee * 0.18)}</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-lg mb-2">Payment Method</h3>
            <div className="space-y-3">
              <div className="border rounded-md p-3 flex items-center cursor-pointer bg-blue-50">
                <input type="radio" name="payment_method" id="upi" className="mr-3" checked readOnly />
                <label htmlFor="upi" className="flex-grow cursor-pointer">UPI Payment</label>
              </div>
              
              <div className="border rounded-md p-3 flex items-center cursor-not-allowed opacity-50">
                <input type="radio" name="payment_method" id="card" className="mr-3" disabled />
                <label htmlFor="card" className="flex-grow cursor-not-allowed">Card Payment (Coming Soon)</label>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => setIsPaymentModalOpen(false)}
              disabled={isProcessingPayment}
            >
              Cancel
            </Button>
            <Button
              isLoading={isProcessingPayment}
              onClick={handlePayment}
            >
              Pay Now
            </Button>
          </div>
        </div>
      </Modal>
      
      {/* Rules Acceptance Modal */}
      <Modal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
        title="Before You Begin"
      >
        <div className="space-y-6">
          <div className="p-4 bg-yellow-50 rounded-md border border-yellow-200">
            <h3 className="font-medium text-lg mb-2 text-yellow-800">Important Rules</h3>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>You have <span className="font-bold">3 minutes</span> to answer 30 questions</li>
              <li>Do not leave the quiz page or open other tabs</li>
              <li>Taking screenshots or copying questions is strictly prohibited</li>
              <li>Any violation of these rules may lead to disqualification</li>
            </ul>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-md border border-blue-200">
            <h3 className="font-medium text-lg mb-2 text-blue-800">Anti-Cheating Measures</h3>
            <p className="text-gray-700">
              Our system monitors for tab switching, question copying, and other violations. Any suspicious activity will be flagged and may result in disqualification without refund.
            </p>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => setIsRulesModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAcceptRules}
            >
              I Understand & Accept
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default TournamentDetails;