import React, { useState, useEffect } from 'react';
import { getAllUsers, getAllQuizAttempts, getQuizAttemptsByUserId } from '../../services/tournamentService';
import { User, QuizAttempt } from '../../types';
import Button from '../common/Button';
import Card, { CardBody } from '../common/Card';
import Modal from '../common/Modal';

const UserReports: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [userAttempts, setUserAttempts] = useState<QuizAttempt[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  useEffect(() => {
    // Load users and attempts
    const loadData = () => {
      const allUsers = getAllUsers();
      const allAttempts = getAllQuizAttempts();
      
      setUsers(allUsers);
      setAttempts(allAttempts);
    };
    
    loadData();
  }, []);
  
  // Filter users based on search term
  const filteredUsers = users.filter(user => {
    return (
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.mobile.includes(searchTerm)
    );
  });
  
  // View user details
  const viewUserDetails = (user: User) => {
    setSelectedUser(user);
    const userAttempts = getQuizAttemptsByUserId(user.id);
    setUserAttempts(userAttempts);
    setIsModalOpen(true);
  };
  
  // Calculate average score
  const calculateAverageScore = (attempts: QuizAttempt[]) => {
    if (attempts.length === 0) return 0;
    const totalScore = attempts.reduce((sum, attempt) => sum + attempt.score, 0);
    return (totalScore / attempts.length).toFixed(2);
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Generate CSV for all users
  const generateAllUsersCSV = () => {
    const headers = ['User ID', 'Name', 'Mobile', 'Total Attempts', 'Average Score'];
    const rows = users.map(user => {
      const userAttempts = attempts.filter(attempt => attempt.userId === user.id);
      const averageScore = calculateAverageScore(userAttempts);
      
      return [
        user.id,
        user.name,
        user.mobile,
        userAttempts.length,
        averageScore
      ];
    });
    
    return [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
  };
  
  // Generate CSV for user attempts
  const generateUserAttemptsCSV = () => {
    if (!selectedUser) return '';
    
    const headers = [
      'Attempt ID',
      'Tournament ID',
      'Start Time',
      'End Time',
      'Score',
      'Total Questions',
      'Correct Answers'
    ];
    
    const rows = userAttempts.map(attempt => {
      return [
        attempt.id,
        attempt.tournamentId,
        formatDate(attempt.startTime),
        formatDate(attempt.endTime),
        attempt.score,
        attempt.totalQuestions,
        attempt.correctAnswers
      ];
    });
    
    return [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
  };
  
  // Download CSV
  const downloadCSV = (csvContent: string, fileName: string) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Handle download all users report
  const handleDownloadAllUsersReport = () => {
    const csvContent = generateAllUsersCSV();
    downloadCSV(csvContent, 'all_users_report.csv');
  };
  
  // Handle download user attempts report
  const handleDownloadUserAttemptsReport = () => {
    if (!selectedUser) return;
    
    const csvContent = generateUserAttemptsCSV();
    downloadCSV(csvContent, `user_${selectedUser.id}_attempts.csv`);
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">User Reports</h1>
        
        <Button onClick={handleDownloadAllUsersReport}>
          Download All Users Report
        </Button>
      </div>
      
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search users by name or mobile..."
            className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Mobile
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quizzes Taken
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Average Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                    No users found.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => {
                  const userAttempts = attempts.filter(attempt => attempt.userId === user.id);
                  const averageScore = calculateAverageScore(userAttempts);
                  
                  return (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <span className="text-blue-600 font-medium">{user.name.charAt(0).toUpperCase()}</span>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{user.name}</div>
                            <div className="text-sm text-gray-500">ID: {user.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.mobile}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {userAttempts.length}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{averageScore}%</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          className="text-blue-600 hover:text-blue-900"
                          onClick={() => viewUserDetails(user)}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* User Details Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedUser ? `${selectedUser.name}'s Quiz History` : 'User Details'}
        size="lg"
      >
        {selectedUser && (
          <div>
            <div className="bg-blue-50 p-4 rounded-md mb-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-lg">{selectedUser.name.charAt(0).toUpperCase()}</span>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">{selectedUser.name}</h3>
                  <p className="text-sm text-gray-600">Mobile: {selectedUser.mobile}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="p-2 bg-white rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">Total Quizzes</p>
                  <p className="text-xl font-bold">{userAttempts.length}</p>
                </div>
                <div className="p-2 bg-white rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">Average Score</p>
                  <p className="text-xl font-bold">{calculateAverageScore(userAttempts)}%</p>
                </div>
                <div className="p-2 bg-white rounded-md shadow-sm">
                  <p className="text-sm text-gray-500">Best Score</p>
                  <p className="text-xl font-bold">
                    {userAttempts.length > 0
                      ? Math.max(...userAttempts.map(a => a.score)).toFixed(2) + '%'
                      : '0%'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mb-4 flex justify-end">
              <Button
                onClick={handleDownloadUserAttemptsReport}
                variant="outline"
                size="sm"
              >
                Download Report
              </Button>
            </div>
            
            {userAttempts.length === 0 ? (
              <Card>
                <CardBody>
                  <p className="text-center text-gray-500">No quiz attempts found for this user.</p>
                </CardBody>
              </Card>
            ) : (
              <div className="space-y-4">
                {userAttempts.map((attempt) => (
                  <Card key={attempt.id}>
                    <CardBody>
                      <div className="flex flex-col md:flex-row justify-between mb-4">
                        <div>
                          <h4 className="font-medium">Quiz Attempt: {attempt.id}</h4>
                          <p className="text-sm text-gray-500">Tournament: {attempt.tournamentId}</p>
                        </div>
                        <div className="text-right mt-2 md:mt-0">
                          <p className="text-sm text-gray-500">Date: {formatDate(attempt.startTime)}</p>
                          <p className="text-sm text-gray-500">
                            Duration: {Math.round((new Date(attempt.endTime).getTime() - new Date(attempt.startTime).getTime()) / 1000 / 60)} minutes
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-blue-50 p-3 rounded-md text-center">
                          <p className="text-sm text-gray-600">Score</p>
                          <p className="text-xl font-bold text-blue-600">{attempt.score.toFixed(2)}%</p>
                        </div>
                        <div className="bg-green-50 p-3 rounded-md text-center">
                          <p className="text-sm text-gray-600">Correct</p>
                          <p className="text-xl font-bold text-green-600">{attempt.correctAnswers} / {attempt.totalQuestions}</p>
                        </div>
                        <div className="bg-red-50 p-3 rounded-md text-center">
                          <p className="text-sm text-gray-600">Incorrect</p>
                          <p className="text-xl font-bold text-red-600">{attempt.totalQuestions - attempt.correctAnswers} / {attempt.totalQuestions}</p>
                        </div>
                      </div>
                      
                      <div className="border-t pt-4">
                        <h5 className="font-medium mb-2">Question Details</h5>
                        <div className="text-sm text-gray-600">
                          <p>Total Questions: {attempt.totalQuestions}</p>
                          <p>Answered Questions: {attempt.answers.length}</p>
                          <p>Skipped Questions: {attempt.totalQuestions - attempt.answers.length}</p>
                        </div>
                      </div>
                    </CardBody>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default UserReports;