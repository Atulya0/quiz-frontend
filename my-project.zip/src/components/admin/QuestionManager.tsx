import React, { useState, useEffect } from 'react';
import { Question } from '../../types';
import Button from '../common/Button';
import Input from '../common/Input';
import Modal from '../common/Modal';
import { getAllQuestions, addQuestion, updateQuestion, deleteQuestion } from '../../services/tournamentService';

const QuestionManager: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');
  
  // Form state
  const [formData, setFormData] = useState<Omit<Question, 'id'>>({
    text: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    category: '',
    difficulty: 'medium'
  });
  
  // Load questions
  useEffect(() => {
    const loadQuestions = () => {
      const allQuestions = getAllQuestions();
      setQuestions(allQuestions);
    };
    
    loadQuestions();
  }, []);
  
  // Get unique categories for filter
  const categories = ['all', ...new Set(questions.map(q => q.category))];
  
  // Filter questions
  const filteredQuestions = questions.filter(question => {
    const matchesSearch = question.text.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || question.category === categoryFilter;
    const matchesDifficulty = difficultyFilter === 'all' || question.difficulty === difficultyFilter;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });
  
  // Handle form change
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name.startsWith('option')) {
      const index = parseInt(name.replace('option', ''));
      const newOptions = [...formData.options];
      newOptions[index] = value;
      
      setFormData(prev => ({
        ...prev,
        options: newOptions
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: name === 'correctAnswer' ? parseInt(value) : value
      }));
    }
  };
  
  // Validate form
  const validateForm = () => {
    const errors: { [key: string]: string } = {};
    
    if (!formData.text.trim()) {
      errors.text = 'Question text is required';
    }
    
    if (!formData.category.trim()) {
      errors.category = 'Category is required';
    }
    
    formData.options.forEach((option, index) => {
      if (!option.trim()) {
        errors[`option${index}`] = `Option ${index + 1} is required`;
      }
    });
    
    // Check for duplicate options
    const uniqueOptions = new Set(formData.options.map(opt => opt.trim()));
    if (uniqueOptions.size !== formData.options.length) {
      errors.options = 'All options must be unique';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Handle add question
  const handleAddQuestion = () => {
    if (!validateForm()) {
      return;
    }
    
    const newQuestion: Question = {
      id: `question${Date.now()}`,
      ...formData
    };
    
    addQuestion(newQuestion);
    setQuestions(getAllQuestions());
    resetForm();
    setIsAddModalOpen(false);
  };
  
  // Handle edit question
  const handleEditQuestion = () => {
    if (!validateForm() || !currentQuestion) {
      return;
    }
    
    const updatedQuestion: Question = {
      id: currentQuestion.id,
      ...formData
    };
    
    updateQuestion(updatedQuestion);
    setQuestions(getAllQuestions());
    resetForm();
    setIsEditModalOpen(false);
  };
  
  // Handle delete question
  const handleDeleteQuestion = () => {
    if (currentQuestion) {
      deleteQuestion(currentQuestion.id);
      setQuestions(getAllQuestions());
      setCurrentQuestion(null);
      setIsDeleteModalOpen(false);
    }
  };
  
  // Reset form
  const resetForm = () => {
    setFormData({
      text: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
      category: '',
      difficulty: 'medium'
    });
    setFormErrors({});
  };
  
  // Open edit modal
  const openEditModal = (question: Question) => {
    setCurrentQuestion(question);
    setFormData({
      text: question.text,
      options: [...question.options],
      correctAnswer: question.correctAnswer,
      category: question.category,
      difficulty: question.difficulty
    });
    setIsEditModalOpen(true);
  };
  
  // Open delete modal
  const openDeleteModal = (question: Question) => {
    setCurrentQuestion(question);
    setIsDeleteModalOpen(true);
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">Manage Questions</h1>
        
        <Button onClick={() => {
          resetForm();
          setIsAddModalOpen(true);
        }}>
          Add New Question
        </Button>
      </div>
      
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Input
            placeholder="Search questions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            fullWidth
          />
          
          <div>
            <select
              className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              {categories.map((category, index) => (
                <option key={index} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <select
              className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              value={difficultyFilter}
              onChange={(e) => setDifficultyFilter(e.target.value)}
            >
              <option value="all">All Difficulties</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Question
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Difficulty
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredQuestions.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                    No questions found.
                  </td>
                </tr>
              ) : (
                filteredQuestions.map((question) => (
                  <tr key={question.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-normal text-sm text-gray-900 max-w-md">
                      {question.text}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {question.category}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        question.difficulty === 'easy'
                          ? 'bg-green-100 text-green-800'
                          : question.difficulty === 'medium'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                      }`}>
                        {question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        className="text-blue-600 hover:text-blue-900 mr-3"
                        onClick={() => openEditModal(question)}
                      >
                        Edit
                      </button>
                      <button
                        className="text-red-600 hover:text-red-900"
                        onClick={() => openDeleteModal(question)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Add Question Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Question"
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Question Text
            </label>
            <textarea
              name="text"
              value={formData.text}
              onChange={handleFormChange}
              className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              rows={3}
            ></textarea>
            {formErrors.text && <p className="mt-1 text-sm text-red-600">{formErrors.text}</p>}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <input
                type="text"
                name="category"
                value={formData.category}
                onChange={handleFormChange}
                className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
                placeholder="e.g., Science, History, Sports"
              />
              {formErrors.category && <p className="mt-1 text-sm text-red-600">{formErrors.category}</p>}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Difficulty
              </label>
              <select
                name="difficulty"
                value={formData.difficulty}
                onChange={handleFormChange}
                className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Options
            </label>
            {formErrors.options && <p className="mt-1 text-sm text-red-600">{formErrors.options}</p>}
            
            {formData.options.map((option, index) => (
              <div key={index} className="flex items-center mb-2">
                <div className="flex-shrink-0 mr-2">
                  <input
                    type="radio"
                    name="correctAnswer"
                    value={index}
                    checked={formData.correctAnswer === index}
                    onChange={handleFormChange}
                    className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300"
                  />
                </div>
                <div className="flex-grow">
                  <input
                    type="text"
                    name={`option${index}`}
                    value={option}
                    onChange={handleFormChange}
                    className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
                    placeholder={`Option ${index + 1}`}
                  />
                  {formErrors[`option${index}`] && <p className="mt-1 text-sm text-red-600">{formErrors[`option${index}`]}</p>}
                </div>
              </div>
            ))}
            <p className="text-sm text-gray-500 mt-2">Select the radio button next to the correct answer.</p>
          </div>
          
          <div className="flex justify-end space-x-3 mt-6">
            <Button
              variant="outline"
              onClick={() => setIsAddModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddQuestion}
            >
              Add Question
            </Button>
          </div>
        </div>
      </Modal>
      
      {/* Edit Question Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Question"
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Question Text
            </label>
            <textarea
              name="text"
              value={formData.text}
              onChange={handleFormChange}
              className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              rows={3}
            ></textarea>
            {formErrors.text && <p className="mt-1 text-sm text-red-600">{formErrors.text}</p>}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <input
                type="text"
                name="category"
                value={formData.category}
                onChange={handleFormChange}
                className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              />
              {formErrors.category && <p className="mt-1 text-sm text-red-600">{formErrors.category}</p>}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Difficulty
              </label>
              <select
                name="difficulty"
                value={formData.difficulty}
                onChange={handleFormChange}
                className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Options
            </label>
            {formErrors.options && <p className="mt-1 text-sm text-red-600">{formErrors.options}</p>}
            
            {formData.options.map((option, index) => (
              <div key={index} className="flex items-center mb-2">
                <div className="flex-shrink-0 mr-2">
                  <input
                    type="radio"
                    name="correctAnswer"
                    value={index}
                    checked={formData.correctAnswer === index}
                    onChange={handleFormChange}
                    className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300"
                  />
                </div>
                <div className="flex-grow">
                  <input
                    type="text"
                    name={`option${index}`}
                    value={option}
                    onChange={handleFormChange}
                    className="w-full px-3 py-2 bg-white border shadow-sm border-slate-300 rounded-md"
                    placeholder={`Option ${index + 1}`}
                  />
                  {formErrors[`option${index}`] && <p className="mt-1 text-sm text-red-600">{formErrors[`option${index}`]}</p>}
                </div>
              </div>
            ))}
            <p className="text-sm text-gray-500 mt-2">Select the radio button next to the correct answer.</p>
          </div>
          
          <div className="flex justify-end space-x-3 mt-6">
            <Button
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditQuestion}
            >
              Update Question
            </Button>
          </div>
        </div>
      </Modal>
      
      {/* Delete Question Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Question"
      >
        <div className="p-4 bg-red-50 rounded-md mb-4">
          <p className="text-red-800">
            Are you sure you want to delete this question? This action cannot be undone.
          </p>
        </div>
        
        {currentQuestion && (
          <div className="mb-4 p-4 border rounded-md">
            <p className="font-medium">{currentQuestion.text}</p>
          </div>
        )}
        
        <div className="flex justify-end space-x-3">
          <Button
            variant="outline"
            onClick={() => setIsDeleteModalOpen(false)}
          >
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={handleDeleteQuestion}
          >
            Delete Question
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default QuestionManager;