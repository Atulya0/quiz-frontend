import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Tournament } from '../../types';
import Card, { CardBody, CardFooter } from '../common/Card';
import Button from '../common/Button';

interface TournamentCardProps {
  tournament: Tournament;
}

const TournamentCard: React.FC<TournamentCardProps> = ({ tournament }) => {
  const navigate = useNavigate();
  
  const getStatusBadgeClass = (status: Tournament['status']) => {
    switch (status) {
      case 'upcoming':
        return 'bg-yellow-100 text-yellow-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getStatusText = (status: Tournament['status']) => {
    switch (status) {
      case 'upcoming':
        return 'Upcoming';
      case 'active':
        return 'Active';
      case 'completed':
        return 'Completed';
      default:
        return 'Unknown';
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };
  
  const handleViewDetails = () => {
    navigate(`/tournament/${tournament.id}`);
  };
  
  return (
    <Card hoverable className="h-full flex flex-col transform transition-all duration-300 hover:scale-[1.02]">
      <div 
        className="h-32 bg-gradient-to-r from-blue-500 to-purple-600 p-4 flex items-end"
      >
        <div>
          <span className={`inline-block px-2 py-1 text-xs font-medium rounded-md ${getStatusBadgeClass(tournament.status)}`}>
            {getStatusText(tournament.status)}
          </span>
          <h3 className="text-xl font-bold text-white mt-2">{tournament.title}</h3>
        </div>
      </div>
      
      <CardBody className="flex-grow">
        <p className="text-gray-600 mb-4">{tournament.description}</p>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Entry Fee</p>
            <p className="font-bold text-blue-600">₹{tournament.entryFee}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Prize Pool</p>
            <p className="font-bold text-purple-600">₹{tournament.prizePool}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Starts</p>
            <p className="font-medium">{formatDate(tournament.startDate)}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Ends</p>
            <p className="font-medium">{formatDate(tournament.endDate)}</p>
          </div>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2 mb-1">
          <div 
            className="bg-blue-600 h-2 rounded-full" 
            style={{ width: `${(tournament.playerCount / tournament.maxPlayers) * 100}%` }}
          ></div>
        </div>
        <p className="text-sm text-gray-500">{tournament.playerCount} / {tournament.maxPlayers} players</p>
      </CardBody>
      
      <CardFooter className="border-t">
        <Button 
          variant={tournament.status === 'active' ? 'primary' : tournament.status === 'upcoming' ? 'secondary' : 'outline'} 
          fullWidth
          onClick={handleViewDetails}
          disabled={tournament.status === 'completed'}
        >
          {tournament.status === 'active' ? 'Enter Tournament' : 
           tournament.status === 'upcoming' ? 'Register Now' : 'View Results'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TournamentCard;