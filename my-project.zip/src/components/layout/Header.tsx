import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navigateTo = (path: string) => {
    navigate(path);
    setIsDropdownOpen(false);
  };

  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center" onClick={() => navigate('/')} style={{ cursor: 'pointer' }}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-2" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M8.812 9.483a2.57 2.57 0 0 0-.786-1.287A2.57 2.57 0 0 0 6.7 7.5H3.5A1.5 1.5 0 0 0 2 9v1.909l1.279.855L4.2 11.1a2 2 0 0 1 .9.9l.3.6"></path>
              <path d="M1.998 17 2 13l6-2.958V7.5"></path>
              <path d="M15.194 9.482a2.57 2.57 0 0 1 .787-1.287A2.57 2.57 0 0 1 17.3 7.5H20.5a1.5 1.5 0 0 1 1.5 1.5v1.909l-1.279.855L19.8 11.1a2 2 0 0 0-.9.9l-.3.6"></path>
              <path d="M21.998 17 22 13l-6-2.958V7.5"></path>
              <path d="M12 22v-5"></path>
              <path d="m9 9 1.5-1.5h3L15 9"></path>
              <path d="M8 13v-2a4 4 0 0 1 8 0v2"></path>
              <rect width="16" height="7" x="4" y="13" rx="2"></rect>
            </svg>
            <h1 className="text-xl font-bold">QuizMaster</h1>
          </div>

          {user && (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center space-x-2 focus:outline-none"
              >
                <div className="w-8 h-8 rounded-full bg-white/30 flex items-center justify-center">
                  <span className="text-sm font-medium">{user.name.charAt(0).toUpperCase()}</span>
                </div>
                <span className="hidden md:inline-block">{user.name}</span>
                <svg
                  className={`h-5 w-5 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`}
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>

              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 py-2 bg-white rounded-md shadow-xl z-20 text-gray-800 animate-fade-in">
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm hover:bg-gray-100"
                    onClick={() => navigateTo('/profile')}
                  >
                    My Profile
                  </a>
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm hover:bg-gray-100"
                    onClick={() => navigateTo('/history')}
                  >
                    My Quiz History
                  </a>
                  {user.isAdmin && (
                    <a
                      href="#"
                      className="block px-4 py-2 text-sm hover:bg-gray-100"
                      onClick={() => navigateTo('/admin')}
                    >
                      Admin Dashboard
                    </a>
                  )}
                  <div className="border-t border-gray-100 my-1"></div>
                  <a
                    href="#"
                    className="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                    onClick={handleLogout}
                  >
                    Logout
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;