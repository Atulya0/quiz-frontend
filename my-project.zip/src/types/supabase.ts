export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string
          mobile: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          mobile: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          mobile?: string
          created_at?: string
        }
      }
      tournaments: {
        Row: {
          id: string
          title: string
          description: string | null
          entry_fee: number
          prize_pool: number
          start_date: string
          end_date: string
          player_count: number
          max_players: number
          status: 'upcoming' | 'active' | 'completed'
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          entry_fee?: number
          prize_pool?: number
          start_date: string
          end_date: string
          player_count?: number
          max_players?: number
          status: 'upcoming' | 'active' | 'completed'
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          entry_fee?: number
          prize_pool?: number
          start_date?: string
          end_date?: string
          player_count?: number
          max_players?: number
          status?: 'upcoming' | 'active' | 'completed'
          created_at?: string
        }
      }
      questions: {
        Row: {
          id: string
          text: string
          options: Json
          correct_answer: number
          category: string
          difficulty: 'easy' | 'medium' | 'hard'
          created_at: string
        }
        Insert: {
          id?: string
          text: string
          options: Json
          correct_answer: number
          category: string
          difficulty: 'easy' | 'medium' | 'hard'
          created_at?: string
        }
        Update: {
          id?: string
          text?: string
          options?: Json
          correct_answer?: number
          category?: string
          difficulty?: 'easy' | 'medium' | 'hard'
          created_at?: string
        }
      }
      quiz_attempts: {
        Row: {
          id: string
          user_id: string
          tournament_id: string
          score: number
          total_questions: number
          correct_answers: number
          answers: Json
          start_time: string
          end_time: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          tournament_id: string
          score: number
          total_questions: number
          correct_answers: number
          answers: Json
          start_time: string
          end_time: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          tournament_id?: string
          score?: number
          total_questions?: number
          correct_answers?: number
          answers?: Json
          start_time?: string
          end_time?: string
          created_at?: string
        }
      }
      kyc_details: {
        Row: {
          id: string
          user_id: string
          full_name: string
          date_of_birth: string
          pan_card: string
          account_number: string
          ifsc_code: string
          bank_name: string
          verified: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          full_name: string
          date_of_birth: string
          pan_card: string
          account_number: string
          ifsc_code: string
          bank_name: string
          verified?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string
          date_of_birth?: string
          pan_card?: string
          account_number?: string
          ifsc_code?: string
          bank_name?: string
          verified?: boolean
          created_at?: string
        }
      }
    }
  }
}