export interface User {
  id: string;
  name: string;
  mobile: string;
  isAdmin?: boolean;
}

export interface Tournament {
  id: string;
  title: string;
  description: string;
  entryFee: number;
  prizePool: number;
  startDate: string;
  endDate: string;
  playerCount: number;
  maxPlayers: number;
  status: 'upcoming' | 'active' | 'completed';
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface QuizAttempt {
  id: string;
  userId: string;
  tournamentId: string;
  startTime: string;
  endTime: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  answers: {
    questionId: string;
    selectedOption: number;
    isCorrect: boolean;
    timeSpent: number;
  }[];
}

export interface KYCInfo {
  fullName: string;
  dateOfBirth: string;
  panCard: string;
  accountNumber: string;
  ifscCode: string;
  bankName: string;
}

export interface UserWinnings {
  id: string;
  userId: string;
  tournamentId: string;
  amount: number;
  status: 'pending' | 'processing' | 'completed';
  disbursedAt?: string;
}